"""
Сервис с REST API для задания на второй тур школы бэкенд разработки
"""
__author__ = 'Vasnev Ilya'
__maintainer__ = __author__
__email__ = 'ivasnev2002@gmai.com'
__license__ = 'MIT'
__version__ = '0.0.1'


__all__ = (
    '__author__',
    '__email__',
    '__license__',
    '__maintainer__',
    '__version__',
)
